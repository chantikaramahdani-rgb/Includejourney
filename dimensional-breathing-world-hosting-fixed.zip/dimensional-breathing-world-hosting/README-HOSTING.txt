DIMENSIONAL BREATHING — PAKET HOSTING HTML

1. Upload semua isi folder ini ke public_html, Netlify, Vercel, atau GitHub Pages.
2. Pastikan index.html berada di folder utama hosting.
3. Jangan memisahkan folder assets karena berisi visual dunia, QR Saweria, dan narasi audio yang diputar otomatis pada 01:20.
4. Tombol dan QR Saweria mengarah ke: https://saweria.co/Farhanxdickatumbal

Paket ini bersifat statis: tidak membutuhkan Node.js, database, atau API key untuk dijalankan.
